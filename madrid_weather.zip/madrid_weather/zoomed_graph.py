import matplotlib.pyplot as plot
import pandas as pd
import numpy as np

PATH_MADRID = "data/weather_madrid_2019-2022.csv"
PATH_SIM = "data/zoomed_temps.csv"

HOUR_SHIFT = 36

df = pd.read_csv(PATH_MADRID)
real_data = df.iloc[2450-HOUR_SHIFT:7*24+2450-HOUR_SHIFT, 2].reset_index(drop=True)
sim_data = pd.read_csv(PATH_SIM, sep=";", header=None)

sim = pd.to_numeric(sim_data.iloc[0, :7*24].str.replace(",", "."), errors="coerce")

avg_real = np.mean(real_data)
stddev_real = np.sqrt(np.mean((real_data - avg_real)**2))
mean_stddev_real = stddev_real / np.sqrt(len(real_data))

print(f"{avg_real},{stddev_real},{mean_stddev_real}")

plot.plot(sim)
plot.plot(real_data)

plot.show()
